<?php

namespace app\admin\model;

use think\Model;

class TableMakeTables extends Model {

	// 表名
	protected $name = 'tablemake_tables';

	protected static function _initialize() {
		parent::_initialize();
	}

}
