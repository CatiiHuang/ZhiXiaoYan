<?php

namespace app\admin\model;

use think\Model;

class TableMakeFields extends Model {

	// 表名
	protected $name = 'tablemake_fields';

	protected static function _initialize() {
		parent::_initialize();
	}

}
