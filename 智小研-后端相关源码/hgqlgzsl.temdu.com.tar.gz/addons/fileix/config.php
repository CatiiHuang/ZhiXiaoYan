<?php

return array (
  0 => 
  array (
    'name' => 'root_dir',
    'title' => '根目录地址(所有文件必须有读权限)',
    'type' => 'string',
    'content' => 
    array (
    ),
    'value' => './',
    'rule' => 'required',
    'msg' => '',
    'tip' => '',
    'ok' => '',
    'extend' => '',
  ),
  1 => 
  array (
    'name' => 'ix_height',
    'title' => '框架高度',
    'type' => 'number',
    'content' => 
    array (
    ),
    'value' => '700',
    'rule' => 'required',
    'msg' => '',
    'tip' => '',
    'ok' => '',
    'extend' => '',
  ),
);
