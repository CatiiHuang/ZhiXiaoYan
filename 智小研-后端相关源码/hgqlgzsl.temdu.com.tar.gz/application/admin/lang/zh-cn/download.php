<?php

return [
    'Id'         => 'ID',
    'Kmm'        => '科目名',
    'Zlm'        => '资料名',
    'Ljfile'     => '链接',
    'Xzcs'       => '下载次数',
    'Xx'         => '星星',
    'Dx'         => '大小',
    'Gs'         => '格式',
    'Createtime' => '上传时间',
    'Ms'         => '描述'
];
