<?php

return [
    'Id'            => 'ID',
    'Mz'            => '名字',
    'Jstext'        => '介绍',
    'Lj'            => '链接',
    'Tpimage'       => '图片',
    'Dpdata'        => '店铺',
    'Dpdata 淘宝' => '淘宝',
    'Dpdata 当当' => '当当',
    'Km'            => '科目',
    'Updatetime'    => '更新时间',
    'Xx'            => '星星'
];
